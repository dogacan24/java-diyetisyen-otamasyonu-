package DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RandevuManager {

	 public List<String> getDoctorsInfo() {
	        List<String> doctorsInfo = new ArrayList<>();
	        Connection connection;
	        DbHelper helper = new DbHelper();
	        PreparedStatement statement;
	        ResultSet resultSet;
	        try {
	            connection = helper.getConnection();
	            statement = connection.prepareStatement("SELECT NAME, SURNAME, EXPERIENCE FROM doctors");
	            resultSet = statement.executeQuery();
	            while (resultSet.next()) {
	                String doctorInfo = resultSet.getString("NAME") + " " +
	                                    resultSet.getString("SURNAME") + "  ";
	                doctorsInfo.add(doctorInfo);
	            }
	        } catch (SQLException exception) {
	            helper.showErrorMessage(exception);
	        }
	        return doctorsInfo;
	    }
	 
	 public List<String> getPackagesInfo() {
	        List<String> packagesInfo = new ArrayList<>();
	        Connection connection;
	        DbHelper helper = new DbHelper();
	        PreparedStatement statement;
	        ResultSet resultSet;
	        try {
	            connection = helper.getConnection();
	            statement = connection.prepareStatement("SELECT NAME, DESCRIPTION, PRİCE FROM packages");
	            resultSet = statement.executeQuery();
	            while (resultSet.next()) {
	                String packageInfo = resultSet.getString("NAME") + " " +
	                                    resultSet.getString("PRİCE") + "  " + 
	                                    resultSet.getString("DESCRIPTION");
	                packagesInfo.add(packageInfo);
	            }
	        } catch (SQLException exception) {
	            helper.showErrorMessage(exception);
	        }
	        return packagesInfo;
	    }

	 public void saveAppointment(Appointment appointment) {
	        Connection connection;
	        DbHelper helper = new DbHelper();
	        PreparedStatement statement;

	        try {
	            connection = helper.getConnection();
	            String sql = "INSERT INTO appointments (doctor_name, appointment_time, description) VALUES (?, ?, ?)";
	            statement = connection.prepareStatement(sql);
	            statement.setString(1, appointment.getId());
	            statement.setString(2, appointment.getDoctorName());
	            statement.setString(3, appointment.getTime());
	            statement.setString(4, appointment.getPackages());
	            statement.executeUpdate();
	        } catch (SQLException exception) {
	            helper.showErrorMessage(exception);
	        }
	    }
	 public List<Appointment> getAppointment() {
	        List<Appointment> appointmentList = new ArrayList<>();
	        Connection connection;
	        DbHelper helper = new DbHelper();
	        Statement statement;
	        ResultSet resultSet;
	        try {
	            connection = helper.getConnection();
	            statement = connection.createStatement();
	            resultSet = statement.executeQuery("SELECT * FROM appointments");
	            while (resultSet.next()) {
	            	Appointment appointment = new Appointment();
	            	appointment.setId(resultSet.getString("id"));
	            	appointment.setDoctorName(resultSet.getString("doctor_name"));
	            	appointment.setTime(resultSet.getString("appointment_time"));
	            	appointment.setPackages(resultSet.getString("package_type"));
	            	
	              
	            	appointmentList.add(appointment);
	            }
	        } catch (SQLException exception) {
	            helper.showErrorMessage(exception);
	        }
	        return appointmentList;
	    }
	 
	 
	}
