package DataBase;

public class AuthManager {
    private static boolean loggedIn = false;
    private static boolean isAdmin = false;

    public static boolean isLoggedIn() {
        return loggedIn;
    }

    public static void login(String username, String password) {
       
        if (username.equals("ADMIN") && password.equals("123")) {
            loggedIn = true;
            isAdmin = true;
        } else {
            loggedIn = true;
            isAdmin = false;
        }
    }


    public static void logout() {
        loggedIn = false;
        isAdmin = false;
    }

    public static boolean isAdmin() {
        return isAdmin;
    }
}