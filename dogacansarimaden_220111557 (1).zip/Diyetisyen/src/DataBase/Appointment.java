package DataBase;



public class Appointment {
    private String id;
    private String doctorName;
    private String time;
    private String packages;
    
    public Appointment(){
    	
    }

    public Appointment(String id, String doctorName, String time, String packages) {
        this.id = id;
        this.doctorName = doctorName;
        this.time = time;
        this.packages = packages;
    }

    // Getter ve setter metodları
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPackages() {
        return packages;
    }

    public void setPackages(String packages) {
        this.packages = packages;
    }
    
    public String toString() {
        return "Package{" +
                "id=" + id +
                ", name='" + doctorName + '\'' +
                ", packages='" + time + '\'' +
                ", price=" + packages +
                '}';
    }
}
