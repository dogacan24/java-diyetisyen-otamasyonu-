package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbHelper {
    public Connection getConnection() {
        final String userName = "root";
        final String password = "1234";
        final String dbUrl = "jdbc:mysql://localhost:3306/DIYETISYEN?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        try {
            return DriverManager.getConnection(dbUrl, userName, password);
        } catch (SQLException e) {
            showErrorMessage(e);
            return null;
        }
    }

    public void showErrorMessage(SQLException exception) {
        System.out.println("Error : " + exception.getMessage());
        System.out.println("Error code : " + exception.getErrorCode());
    }

    public static void main(String[] args) {
        DbHelper dbHelper = new DbHelper();
        Connection connection = dbHelper.getConnection();
        if (connection != null) {
            System.out.println("Bağlantı başarılı bir şekilde oluşturuldu.");
        } else {
            System.out.println("Bağlantı oluşturulurken hata oluştu.");
        }
    }
}
