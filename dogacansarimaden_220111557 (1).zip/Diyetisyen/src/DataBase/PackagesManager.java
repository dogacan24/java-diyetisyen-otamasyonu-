package DataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PackagesManager
{
    public void insert(String name, String description,String price)
    {
        Connection connection;
        DbHelper helper = new DbHelper();
        PreparedStatement statement;
        try{
            connection = helper.getConnection();
            String sql = "insert into packages (NAME,DESCRIPTION,PRICE) values (?,?,?)";
            statement = connection.prepareStatement(sql);
            statement.setString(1,name);
            statement.setString(2,description);
            statement.setString(3,price);
            statement.executeUpdate();
        }catch (SQLException exception){
            helper.showErrorMessage(exception);
        }
    }
    
    public Packages searchPackage(String keyword) {
    	Packages packages = null;
        Connection connection;
        DbHelper helper = new DbHelper();
        PreparedStatement statement;
        ResultSet resultSet;
        try {
            connection = helper.getConnection();
            String sql = "SELECT * FROM packages WHERE NAME LIKE ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, "%" + keyword + "%");
           
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
            	packages = new Packages();
            	packages.setId(resultSet.getInt("ID"));
            	packages.setName(resultSet.getString("NAME"));
            	packages.setDescription(resultSet.getString("DESCRIPTION"));
            	packages.setPrice(resultSet.getString("PRICE"));
           
            }
        } catch (SQLException exception) {
            helper.showErrorMessage(exception);
        }
        return packages;
    }

    
    public void deletePackage(Packages packages) {
    	
    	  System.out.println(packages.getId());
    	
        Connection connection;
        DbHelper helper = new DbHelper();
        PreparedStatement statement;
        try {
            connection = helper.getConnection();
            String sql = "DELETE FROM packages WHERE ID = ?";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, packages.getId());
            statement.executeUpdate();
        } catch (SQLException exception) {
            helper.showErrorMessage(exception);
        }
    }

    
    public List<Packages> getPackages() {
        List<Packages> packagesList = new ArrayList<>();
        Connection connection;
        DbHelper helper = new DbHelper();
        Statement statement;
        ResultSet resultSet;
        try {
            connection = helper.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM packages");
            while (resultSet.next()) {
            	Packages packages = new Packages();
            	packages.setId(resultSet.getInt("ID"));
            	packages.setName(resultSet.getString("NAME"));
            	packages.setDescription(resultSet.getString("DESCRIPTION"));
            	packages.setPrice(resultSet.getString("PRICE"));
            	
              
            	packagesList.add(packages);
            }
        } catch (SQLException exception) {
            helper.showErrorMessage(exception);
        }
        return packagesList;
    }


    public int loginControl(String userName, String password)
    {
        Connection connection;
        DbHelper helper = new DbHelper();
        PreparedStatement statement;
        ResultSet resultSet;
        try {
            connection = helper.getConnection();
            statement = connection.prepareStatement("Select * from users where USERNAME=? and PASSWORD=?");
            statement.setString(1,userName);
            statement.setString(2,password);
            resultSet = statement.executeQuery();
            if(resultSet.next()) {
                return 0;
            } else {
                return 1;
            }
        }catch (SQLException exception){
            System.out.println("SQLException yakalandı.");
            helper.showErrorMessage(exception);
            return 1;
        }

    }
    public int usernameControl(String userName)
    {
        Connection connection;
        DbHelper helper = new DbHelper();
        PreparedStatement statement;
        ResultSet resultSet;
        try {
            connection = helper.getConnection();
            statement = connection.prepareStatement("Select * from users where USERNAME=?");
            statement.setString(1,userName);
            resultSet = statement.executeQuery();
            if(resultSet.next()) {
                return 0;
            } else {
                return 1;
            }
        }catch (SQLException exception){
            helper.showErrorMessage(exception);
            return 0;
        }
    }
    public String nameSurname(String userName)
    {
        Connection connection;
        DbHelper helper = new DbHelper();
        PreparedStatement statement;
        ResultSet resultSet;
        try {
            connection = helper.getConnection();
            statement = connection.prepareStatement("Select NAME,SURNAME from users where USERNAME=?");
            statement.setString(1,userName);
            resultSet = statement.executeQuery();
            String nameAndSurname = "Hata1";
            while (resultSet.next()){
                nameAndSurname = resultSet.getString("NAME")+" "+resultSet.getString("SURNAME");
            }
            return nameAndSurname;
        }catch (SQLException exception){
            helper.showErrorMessage(exception);
            return "Hata";
        }
    }

    public int numberOfUser()
    {
        int toplam = 0;
        Connection connection;
        DbHelper helper = new DbHelper();
        Statement statement;
        ResultSet resultSet;
        try{
            connection = helper.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select (ID) from users");
            while (resultSet.next()){
                toplam ++;
            }
            return toplam;
        }catch (SQLException exception){
            return toplam;
        }
    }
}