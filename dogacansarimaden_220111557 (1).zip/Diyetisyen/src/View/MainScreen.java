package View;

import DataBase.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import javax.swing.*;
import java.net.URL;
import java.sql.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.function.Predicate;

public class MainScreen implements Initializable {
	@FXML
	private AnchorPane panelUserListe;
	@FXML
	private AnchorPane PanelDiyetListesi;
	@FXML
	private AnchorPane PanelPaketListesi;
	@FXML
	private AnchorPane PanelRandevuAl;
	@FXML
	private AnchorPane panelAppointmentList;
	@FXML
	private AnchorPane vucutAnaliz;
	@FXML
	private AnchorPane panelCikis;
	@FXML
	private AnchorPane panelProfil;
	@FXML
	private Label lblUyeler;
	@FXML
	private Label lblDiyetisyenler;
	@FXML
	private Label lblPaket;
	@FXML
	private Label lblRandevuAl;
	@FXML
	private Label lblVucutAnaliz;
	@FXML
	private Label lblRandevuBilgileri;
	@FXML
	private Label lblCikis;

	@FXML
	private TextField textYas;
	@FXML
	private TextField textKilo;
	@FXML
	private TextField textBoy;
	@FXML
	private Button createAppointmentButton;
	
	@FXML
	private ComboBox<String> comboBoxType;
	@FXML
	private TextField textBoyunCevresi;
	@FXML
	private PasswordField textAdminPassword;
	@FXML
	private TextField textBookSearch;
	@FXML
	private TextField textBorrowUserName;
	@FXML
	private TextField textBorrowBookName;
	@FXML
	private TextField textReturnBookName;
	@FXML
	private TextField textReturnUserName;

	@FXML
	private Label labelName;
	@FXML
	private Label labelSurname;
	@FXML
	private Label textProfilName;
	@FXML
	private Label textProfilUserName;
	@FXML
	private Label textProfilBorrowBook;
	@FXML
	private Button btnProfil;
	@FXML
	private Button btnBorrow;
	@FXML
	private Button btnReturn;
	@FXML
	private Button btnAnaliz;
	@FXML
	private Button btnExit;
	@FXML
	private Button btnUserDelete;

	@FXML
	private AnchorPane panelKullanicilar;
	@FXML
	private TableView<Users> tableUsers;
	@FXML
	private TableView<Doctors> tableDoctors;
	@FXML
	private TableView<Packages> tablePackages;
	@FXML
	private TableView<Appointment> appointmentTable;
	@FXML
	private Map<String, Integer> typeIDMap;
	@FXML
	private TextField SearchUserTextField;

	@FXML
	private ComboBox<String> doctorComboBox;

	@FXML
	private ComboBox<String> timeComboBox;

	@FXML
	private ComboBox<String> packageComboBox;

	@FXML
	private TextArea appointmentDetailsTextArea;
	@FXML
	private TextField textDoctorSearch;
	@FXML
	private TextField textPackageSearch;
	@FXML
	private TableColumn<Users, String> columnUserName;
	@FXML
	private TableColumn<Users, String> columnUserSurname;
	@FXML
	private TableColumn<Users, String> columnUserUsername;
	@FXML
	private TableColumn<Users, String> columnUserTel;
	@FXML
	private TableColumn<Users, String> columnUserMail;

	@FXML
	private TableColumn<Doctors, String> columnDoctorName;
	@FXML
	private TableColumn<Doctors, String> columnDoctorSurname;
	@FXML
	private TableColumn<Doctors, String> columnDoctorExperience;
	@FXML
	private TableColumn<Doctors, String> columnDoctorTelephone;
	@FXML
	private TableColumn<Doctors, String> columnDoctorMail;

	@FXML
	private TableColumn<Packages, String> columnPackageName;
	@FXML
	private TableColumn<Packages, String> columnPackageDescription;
	@FXML
	private TableColumn<Packages, String> columnPackagePrice;
	
	@FXML
	private TableColumn<Appointment, String> columnAppointmentDoctorName;
	@FXML
	private TableColumn<Appointment, String> columnAppointmentTime;
	@FXML
	private TableColumn<Appointment, String> columnAppointmentPackages;

	private ObservableList<Users> userList;
	private ObservableList<Doctors> doctorList;
	private ObservableList<Packages> packageList;
	private ObservableList<Appointment> appointmentList;

	

	@Override
	public void initialize(URL url, ResourceBundle rb) {


		labelName.setText(Login.nowNameAndSurname); 
		labelSurname.setText(Login.nowUserName); 

		addComboBoxType(); 
		comboBoxType.setValue("Türü"); 

		textProfilUserName.setText(Login.nowUserName); 
		textProfilName.setText(Login.nowNameAndSurname); 
		loadUserData();
		loadDoctorData();
		loadPackageData();
		loadAppointmentData();

		if (!AuthManager.isAdmin()) {
			System.out.println(AuthManager.isAdmin());
		
			PanelDiyetListesi.setVisible(false);
			panelUserListe.setVisible(false);
			PanelPaketListesi.setVisible(false);
			lblUyeler.setVisible(false);
			lblPaket.setVisible(false);
			lblDiyetisyenler.setVisible(false);
		} else {
			lblRandevuAl.setVisible(false);
			lblVucutAnaliz.setVisible(false);
			lblRandevuBilgileri.setVisible(false);
			vucutAnaliz.setVisible(false);
			PanelRandevuAl.setVisible(false);
			panelAppointmentList.setVisible(false);

		}

	}

	private void loadUserData() {
		UsersManager usersManager = new UsersManager();
		List<Users> users = usersManager.getUsers();

		userList = FXCollections.observableArrayList(users);

		columnUserName.setCellValueFactory(new PropertyValueFactory<>("name"));
		columnUserSurname.setCellValueFactory(new PropertyValueFactory<>("surname"));
		columnUserUsername.setCellValueFactory(new PropertyValueFactory<>("userName"));
		columnUserTel.setCellValueFactory(new PropertyValueFactory<>("tel"));
		columnUserMail.setCellValueFactory(new PropertyValueFactory<>("mail"));

		tableUsers.setItems(userList);
	}

	private void loadDoctorData() {
		DoctorsManager doctorsManager = new DoctorsManager();
		List<Doctors> doctors = doctorsManager.getDoctors();

		doctorList = FXCollections.observableArrayList(doctors);

		columnDoctorName.setCellValueFactory(new PropertyValueFactory<>("name"));
		columnDoctorSurname.setCellValueFactory(new PropertyValueFactory<>("surname"));
		columnDoctorExperience.setCellValueFactory(new PropertyValueFactory<>("experience"));
		columnDoctorTelephone.setCellValueFactory(new PropertyValueFactory<>("telephone"));
		columnDoctorMail.setCellValueFactory(new PropertyValueFactory<>("mail"));

		tableDoctors.setItems(doctorList);
	}

	private void loadPackageData() {
		PackagesManager packagesManager = new PackagesManager();
		List<Packages> packages = packagesManager.getPackages();

		packageList = FXCollections.observableArrayList(packages);

		columnPackageName.setCellValueFactory(new PropertyValueFactory<>("name"));
		columnPackageDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
		columnPackagePrice.setCellValueFactory(new PropertyValueFactory<>("price"));

		tablePackages.setItems(packageList);
	}
	
	private void loadAppointmentData() {
		RandevuManager randevuManager = new RandevuManager();
		List<Appointment> appointment = randevuManager.getAppointment();

		appointmentList = FXCollections.observableArrayList(appointment);
		
		columnAppointmentDoctorName.setCellValueFactory(new PropertyValueFactory<>("ID"));
		columnAppointmentDoctorName.setCellValueFactory(new PropertyValueFactory<>("DoctorName"));
		columnAppointmentTime.setCellValueFactory(new PropertyValueFactory<>("Time"));
		columnAppointmentPackages.setCellValueFactory(new PropertyValueFactory<>("Packages"));

		appointmentTable.setItems(appointmentList);
	}

	public void btnDoctorInsertDb(ActionEvent event) {
		String anahtarKelime = textDoctorSearch.getText();

		String[] doctorData = anahtarKelime.split(",");

		if (doctorData.length != 5) {
			showAlert("Hatalı giriş!",
					"Tam olarak ad, soyad, deneyim, telefon ve e-posta bilgileri girilmelidir, ve bilgileri virgülle ayırınız.");
			return;
		}

		String name = doctorData[0];
		String surname = doctorData[1];
		String experience = doctorData[2];
		String telephone = doctorData[3];
		String mail = doctorData[4];

		Doctors doctor = new Doctors(name, surname, experience, telephone, mail);

		DoctorsManager manager = new DoctorsManager();
		manager.insert(doctor.getName(), doctor.getSurname(), doctor.getExperience(), doctor.getTelephone(),
				doctor.getMail());

		loadDoctorData();

		textDoctorSearch.clear();

	}

	public void btnPackageInsertDb(ActionEvent event) {
		String anahtarKelime = textPackageSearch.getText();

		String[] packageData = anahtarKelime.split(",");

		if (packageData.length != 3) {
			showAlert("Hatalı giriş!",
					"Tam olarak ad, açıklama ve fiyat bilgileri girilmelidir, ve bilgileri virgülle ayırınız.");
			return;
		}

		String name = packageData[0];
		String description = packageData[1];
		String price = packageData[2];

		Packages packages = new Packages(name, description, price);

		PackagesManager manager = new PackagesManager();
		manager.insert(packages.getName(), packages.getDescription(), packages.getPrice());

		loadPackageData();

		textPackageSearch.clear();

	}

	private void showAlert(String title, String message) {
		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
	}

	public void btnPackageDeleteDb(ActionEvent event) {
		Packages selectedPackages = tablePackages.getSelectionModel().getSelectedItem();
		if (selectedPackages != null) {	
		PackagesManager manager = new PackagesManager();
			manager.deletePackage(selectedPackages); 
			packageList.remove(selectedPackages); 
		} else {
	
			System.out.println("Please select a doctor to delete.");
		}
	}
	

	public void btnPackageSearchDb(ActionEvent event) {
		String anahtarKelime = textPackageSearch.getText();
		if (!anahtarKelime.isEmpty()) {
			PackagesManager paket = new PackagesManager();
			Packages bulunanPaket = paket.searchPackage(anahtarKelime);
			if (bulunanPaket != null) {
				
				System.out.println("Paket bulundu: " + bulunanPaket.getName());

				
				tablePackages.getSelectionModel().clearSelection(); 
				for (Packages packages : packageList) {
					if (packages.getId() == bulunanPaket.getId()) {
						tablePackages.getSelectionModel().select(packages);
						break; 
					}
				}
			} else {
				
				Alert uyari = new Alert(AlertType.INFORMATION);
				uyari.setTitle("Bildiri");
				uyari.setHeaderText(null);
				uyari.setContentText("Kullanıcı bulunamadı.");
				uyari.showAndWait();
			}
		} else {
		
			Alert uyari = new Alert(AlertType.WARNING);
			uyari.setTitle("Bildiri");
			uyari.setHeaderText(null);
			uyari.setContentText("Aramak için lütfen bir anahtar kelime girin.");
			uyari.showAndWait();
		}
	}

	public void btnDoctorDeleteDb(ActionEvent event) {
		Doctors selectedDoctors = tableDoctors.getSelectionModel().getSelectedItem(); 
		
		if (selectedDoctors != null) {
			DoctorsManager doctorsManager = new DoctorsManager();
			doctorsManager.deleteDoctor(selectedDoctors); 
			
			doctorList.remove(selectedDoctors);
		} else {
			
			System.out.println("Please select a doctor to delete.");
		}
	}

	public void btnDoctorSearchDb(ActionEvent event) {
		String anahtarKelime = textDoctorSearch.getText(); 
		if (!anahtarKelime.isEmpty()) {
			DoctorsManager kullanıcıYöneticisi = new DoctorsManager();
			Doctors bulunanKullanıcı = kullanıcıYöneticisi.searchDoctor(anahtarKelime);
			if (bulunanKullanıcı != null) {
				
				System.out.println(
						"Kullanıcı bulundu: " + bulunanKullanıcı.getName() + " " + bulunanKullanıcı.getSurname());

				
				tableUsers.getSelectionModel().clearSelection(); 
				for (Doctors doctor : doctorList) {
					if (doctor.getId() == bulunanKullanıcı.getId()) {
						tableDoctors.getSelectionModel().select(doctor);
						break; 
					}
				}
			} else {
				
				
				Alert uyari = new Alert(AlertType.INFORMATION);
				uyari.setTitle("Bildiri");
				uyari.setHeaderText(null);
				uyari.setContentText("Kullanıcı bulunamadı.");
				uyari.showAndWait();
			}
		} else {
			
			Alert uyari = new Alert(AlertType.WARNING);
			uyari.setTitle("Bildiri");
			uyari.setHeaderText(null);
			uyari.setContentText("Aramak için lütfen bir anahtar kelime girin.");
			uyari.showAndWait();
		}
	}

	public void btnUserDeleteDb(ActionEvent event) {
		Users selectedUser = tableUsers.getSelectionModel().getSelectedItem(); 
		if (selectedUser != null) {
			UsersManager usersManager = new UsersManager();
			usersManager.deleteUser(selectedUser); 
			
			userList.remove(selectedUser); 
		} else {
			
			System.out.println("Please select a user to delete.");
		}
	}

	public void btnUserSearchDb(ActionEvent event) {
		String anahtarKelime = SearchUserTextField.getText(); 
		if (!anahtarKelime.isEmpty()) {
			UsersManager kullanıcıYöneticisi = new UsersManager();
			Users bulunanKullanıcı = kullanıcıYöneticisi.searchUser(anahtarKelime);
			if (bulunanKullanıcı != null) {
				
				System.out.println(
						"Kullanıcı bulundu: " + bulunanKullanıcı.getName() + " " + bulunanKullanıcı.getSurname());

				
				tableUsers.getSelectionModel().clearSelection(); 
				for (Users user : userList) {
					if (user.getId() == bulunanKullanıcı.getId()) {
						tableUsers.getSelectionModel().select(user);
						break; 
					}
				}
			} else {
				
				Alert uyari = new Alert(AlertType.INFORMATION);
				uyari.setTitle("Bildiri");
				uyari.setHeaderText(null);
				uyari.setContentText("Kullanıcı bulunamadı.");
				uyari.showAndWait();
			}
		} else {
			
			Alert uyari = new Alert(AlertType.WARNING);
			uyari.setTitle("Bildiri");
			uyari.setHeaderText(null);
			uyari.setContentText("Aramak için lütfen bir anahtar kelime girin.");
			uyari.showAndWait();
		}
	}

	private int menu = 1;

	@FXML
	void menuUyelerClick(MouseEvent event) {
		menuControl();
		panelUserListe.setVisible(true);
		menu = 1;
	}

	@FXML
	void menuCikisClick(MouseEvent event) {
		menuControl();
		panelCikis.setVisible(true);
		menu = 2;
	}

	@FXML
	void menuRandevuAlClick(MouseEvent event) {
		menuControl();
		PanelRandevuAl.setVisible(true);
		menu = 3;
	}

	@FXML
	void menuVucutAnalizClick(MouseEvent event) {
		menuControl();
		vucutAnaliz.setVisible(true);
		menu = 4;
	}

	@FXML
	void menuDiyetisyenlerClick(MouseEvent event) {
		menuControl();
		PanelDiyetListesi.setVisible(true);
		menu = 5;
	}

	@FXML
	void menuRandevuBilgileriClick(MouseEvent event) {
		menuControl();
		panelAppointmentList.setVisible(true);
		menu = 6;
	}

	@FXML
	void menuPaketClick(MouseEvent event) {
		menuControl();
		PanelPaketListesi.setVisible(true);
		menu = 7;
	}

	@FXML
	void menuProfilClick(MouseEvent event) {
		menuControl();
		panelProfil.setVisible(true);
		menu = 8;
	}

	public void menuControl() {
		switch (menu) {
		case 1:
			panelUserListe.setVisible(false);
			break;
		case 2:
			panelCikis.setVisible(false);
			break;
		case 3:
			PanelRandevuAl.setVisible(false);
			break;
		case 4:
			vucutAnaliz.setVisible(false);
			break;
		case 5:
			PanelDiyetListesi.setVisible(false);
			break;
		case 6:
			panelAppointmentList.setVisible(false);
			break;
		case 7:
			PanelPaketListesi.setVisible(false);
			break;
		case 8:
			panelProfil.setVisible(false);
			break;
		default:
			break;
		}
	}

	public void addComboBoxType() {
		ObservableList<String> list = FXCollections.observableArrayList("Kadın", "Erkek");

		
		
		    doctorComboBox.getItems().addAll(randevuManager.getDoctorsInfo());
	       
	        timeComboBox.getItems().addAll("09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00");
	        packageComboBox.getItems().addAll(randevuManager.getPackagesInfo());
		comboBoxType.setItems(list);


		typeIDMap = new HashMap<>();
		typeIDMap.put("Kadın", 655);
		typeIDMap.put("Erkek", 66);
	}






	@FXML
	public void clickExit(ActionEvent event) {
		System.exit(0);
	}

	@FXML
	public int AnalizEt() {
		double weight, height, bmr;
		int age, genderID;
		
		try {
			weight = Double.parseDouble(textKilo.getText());
			height = Double.parseDouble(textBoy.getText()) / 100; 
			age = Integer.parseInt(textYas.getText());
			genderID = typeIDMap.get(comboBoxType.getValue());
		} catch (NumberFormatException | NullPointerException e) {
			JOptionPane.showMessageDialog(null, "Lütfen geçerli değerler giriniz!");
			return 0;
		}

		
		if (genderID == 655) { // Kadın
			bmr = 655 + (9.6 * weight) + (1.8 * height * 100) - (4.7 * age);
		} else if (genderID == 66) { // Erkek
			bmr = 66 + (13.7 * weight) + (5 * height * 100) - (6.8 * age);
		} else {
			JOptionPane.showMessageDialog(null, "Geçersiz cinsiyet ID'si!");
			return 0;
		}

		double result = weight / (height * height);

		String classification;
		if (result < 18.5) {
			classification = "İdeal kilonun altında";
		} else if (result >= 18.5 && result <= 24.9) {
			classification = "İdeal kiloda";
		} else if (result >= 25 && result <= 29.9) {
			classification = "İdeal kilonun üstünde";
		} else if (result >= 30 && result <= 39.9) {
			classification = "İdeal kilonun çok üstünde (obez)";
		} else {
			classification = "İdeal kilonun çok üstünde (morbid obez)";
		}


		String message = String.format(
				"Bazal Metabolizma Hızı (BMR): %.2f\nVücut Kitle İndeksi: %.2f\nSınıflandırma: %s", bmr, result,
				classification);
		JOptionPane.showMessageDialog(null, message);

	
		textYas.setText("");
		textKilo.setText("");
		textBoy.setText("");
		textBoyunCevresi.setText("");
		comboBoxType.setValue("Cinsiyet");

		return 0;
	}

	private final RandevuManager randevuManager = new RandevuManager();

	  @FXML
	  private void createAppointment() {
	      String selectedDoctor = doctorComboBox.getValue();
	      String selectedTime = timeComboBox.getValue();
	      String selectedPackage = packageComboBox.getValue();

	      if (selectedDoctor != null && selectedTime != null && selectedPackage != null) {
	          Appointment appointment = new Appointment( null ,selectedDoctor, selectedTime, selectedPackage);
	          randevuManager.saveAppointment(appointment);
	          String appointmentDetails = "Randevu Detayları:\nDoktor: " + selectedDoctor +
	                                      "\nSaat: " + selectedTime + "\nPaket: " + selectedPackage;
	          appointmentDetailsTextArea.setText(appointmentDetails);
	      } else {
	          appointmentDetailsTextArea.setText("Lütfen tüm alanları doldurun.");
	      }
	  }





	
	@FXML
	public void enteredUyeler(MouseEvent event) {
		lblUyeler.styleProperty().set("-fx-background-color: #9FA8DA");
	}

	@FXML
	public void enteredDiyetisyenler(MouseEvent event) {
		lblDiyetisyenler.styleProperty().set("-fx-background-color: #9FA8DA");
	}

	@FXML
	public void enteredPaket(MouseEvent event) {
		lblPaket.styleProperty().set("-fx-background-color: #9FA8DA");
	}

	@FXML
	public void enteredRandevuAl(MouseEvent event) {
		lblRandevuAl.styleProperty().set("-fx-background-color: #9FA8DA");
	}

	@FXML
	public void enteredVucutAnalizEkle(MouseEvent event) {
		lblVucutAnaliz.styleProperty().set("-fx-background-color: #9FA8DA");
	}

	@FXML
	public void enteredRandevuBilgileri(MouseEvent event) {
		lblRandevuBilgileri.styleProperty().set("-fx-background-color: #9FA8DA");
	}

	@FXML
	public void enteredCikis(MouseEvent event) {
		lblCikis.styleProperty().set("-fx-background-color: #9FA8DA");
	}

	@FXML
	public void exitedUyeler(MouseEvent event) {
		lblUyeler.styleProperty().set("-fx-background-color: #5C6BC0");
	}

	@FXML
	public void exitedDiyetisyenler(MouseEvent event) {
		lblDiyetisyenler.styleProperty().set("-fx-background-color: #5C6BC0");
	}

	@FXML
	public void exitedPaket(MouseEvent event) {
		lblPaket.styleProperty().set("-fx-background-color: #5C6BC0");
	}

	@FXML
	public void exitedRandevuAl(MouseEvent event) {
		lblRandevuAl.styleProperty().set("-fx-background-color: #5C6BC0");
	}

	@FXML
	public void exitedVucutAnaliz(MouseEvent event) {
		lblVucutAnaliz.styleProperty().set("-fx-background-color: #5C6BC0");
	}

	@FXML
	public void exitedRandevuBilgileri(MouseEvent event) {
		lblRandevuBilgileri.styleProperty().set("-fx-background-color: #5C6BC0");
	}

	@FXML
	public void exitedCikis(MouseEvent event) {
		lblCikis.styleProperty().set("-fx-background-color: #5C6BC0");
	}

	@FXML
	public void btnEnteredProfil(MouseEvent event) {
		btnProfil.styleProperty().set("-fx-background-color: #3F51B5");
	}

	@FXML
	public void btnExitedProfil(MouseEvent event) {
		btnProfil.styleProperty().set("-fx-background-color: #283593");
	}

	@FXML
	public void btnEnteredBorrow(MouseEvent event) {
		btnBorrow.styleProperty().set("-fx-background-color: #3F51B5");
	}

	@FXML
	public void btnExitedBorrow(MouseEvent event) {
		btnBorrow.styleProperty().set("-fx-background-color: #283593");
	}

	@FXML
	public void btnEnteredReturn(MouseEvent event) {
		btnReturn.styleProperty().set("-fx-background-color: #3F51B5");
	}

	@FXML
	public void btnExitedRetrun(MouseEvent event) {
		btnReturn.styleProperty().set("-fx-background-color: #283593");
	}

	@FXML
	public void btnEnteredAdd(MouseEvent event) {
		btnAnaliz.styleProperty().set("-fx-background-color: #3F51B5");
	}

	@FXML
	public void btnExitedAdd(MouseEvent event) {
		btnAnaliz.styleProperty().set("-fx-background-color: #283593");
	}

	@FXML
	public void btnEnteredExit(MouseEvent event) {
		btnExit.styleProperty().set("-fx-background-color: #E57373");
	}

	@FXML
	public void btnExitedExit(MouseEvent event) {
		btnExit.styleProperty().set("-fx-background-color:  #F44336");
	}
}