/**
 * 
 */
/**
 * 
 */
module Diyetisyen {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.sql;
	requires java.desktop;
	requires javafx.graphics;
	opens DataBase to javafx.base;
	opens View to javafx.graphics, javafx.fxml;
}