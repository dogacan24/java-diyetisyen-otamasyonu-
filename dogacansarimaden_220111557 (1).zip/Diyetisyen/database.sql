CREATE DATABASE MarketDatabase;

USE MarketDatabase;

CREATE TABLE Employees (
    EmployeeID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    EmployeePassword VARCHAR(255) NOT NULL,
    EmployeeName VARCHAR(255) NOT NULL,
    EmployeeIDNo VARCHAR(255) NOT NULL,
    EmployeeDepartment VARCHAR(255) NOT NULL,
    EmployeePhone VARCHAR(15) NOT NULL
);

CREATE TABLE Products (
    ProductID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    ProductPrice INT NOT NULL,
    ProductStock INT NOT NULL
);

CREATE TABLE Purchases (
    PurchaseID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Products TEXT NOT NULL,
    TotalPrice INT NOT NULL,
    PurchaseDate DATETIME NOT NULL DEFAULT GETDATE()
);


INSERT INTO Products (ProductName, ProductPrice, ProductStock)
VALUES 
    ('Milk', 50, 100),
    ('Bread', 30, 200),
    ('Eggs', 60, 150),
    ('Rice', 90, 300),
    ('Pasta', 40, 120),
    ('Apples', 70, 80),
    ('Bananas', 50, 100),
    ('Chicken', 200, 50),
    ('Fish', 250, 40),
    ('Potatoes', 20, 500),
    ('Tomatoes', 30, 400),
    ('Onions', 25, 300),
    ('Carrots', 35, 200),
    ('Cheese', 120, 60),
    ('Butter', 110, 70);




INSERT INTO Purchases (Products, TotalPrice)
VALUES 
    ('{1,2}/{2,1}/{3,12}', 450), 
    ('{4,5}/{5,3}/{6,6}', 700), 
    ('{7,8}/{8,2}/{9,3}', 1400), 
    ('{10,10}/{11,8}/{12,5}', 390), 
    ('{13,4}/{14,2}/{15,1}', 410); 



INSERT INTO Employees (EmployeePassword, EmployeeName, EmployeeIDNo, EmployeeDepartment, EmployeePhone)
VALUES 
    ('123', 'John Doe', '1234567890', 'Sales', '555-123-4567'),
    ('123', 'Jane Smith', '1234567890', 'Inventory', '555-987-6543'),
    ('123', 'Alice Johnson', '1234567890', 'Management', '555-321-9876'),
    ('123', 'Bob Brown', '1234567890', 'HR', '555-654-3210'),
    ('123', 'Eve Davis', '1234567890', 'IT', '555-789-1234');
